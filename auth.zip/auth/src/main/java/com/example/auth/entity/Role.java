package com.example.auth.entity;

public enum Role {
    USER,
    ADMIN
}
